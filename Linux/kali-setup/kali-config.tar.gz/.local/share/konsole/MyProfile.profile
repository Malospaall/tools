[Appearance]
ColorScheme=Kali-Dark

[Cursor Options]
CursorShape=1

[General]
Name=MyProfile
Parent=FALLBACK/

[Scrolling]
HistoryMode=2
